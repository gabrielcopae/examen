/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/add-playlist";
exports.ids = ["pages/add-playlist"];
exports.modules = {

/***/ "./styles/AddPlaylist.module.scss":
/*!****************************************!*\
  !*** ./styles/AddPlaylist.module.scss ***!
  \****************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"container\": \"AddPlaylist_container__XJNLj\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvQWRkUGxheWxpc3QubW9kdWxlLnNjc3MuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9leGFtZW4vLi9zdHlsZXMvQWRkUGxheWxpc3QubW9kdWxlLnNjc3M/MjcyZSJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJjb250YWluZXJcIjogXCJBZGRQbGF5bGlzdF9jb250YWluZXJfX1hKTkxqXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/AddPlaylist.module.scss\n");

/***/ }),

/***/ "./pages/add-playlist.js":
/*!*******************************!*\
  !*** ./pages/add-playlist.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ AddPlaylist)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_AddPlaylist_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/AddPlaylist.module.scss */ \"./styles/AddPlaylist.module.scss\");\n/* harmony import */ var _styles_AddPlaylist_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_AddPlaylist_module_scss__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction AddPlaylist() {\n    const { 0: descriere , 1: setDescriere  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');\n    const { 0: ora , 1: setOra  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');\n    const handleSubmit = async (event)=>{\n        event.preventDefault();\n        let date = Date.now();\n        date = Number(String(date).split('').slice(5, 12).join(''));\n        console.log(date);\n    // const form = {\n    //   id: date,\n    //   titlu,\n    //   url,\n    //   stil,\n    // };\n    // await fetch('http://localhost:3000/api/db', {\n    //   headers: {\n    //     'Content-Type': 'application/json',\n    //     'Access-Control-Allow-Origin': '*',\n    //   },\n    //   method: 'POST',\n    //   body: JSON.stringify(form),\n    // });\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: (_styles_AddPlaylist_module_scss__WEBPACK_IMPORTED_MODULE_2___default().container),\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                    children: \"Creeaza playlist\"\n                }, void 0, false, {\n                    fileName: \"E:\\\\Post Internship\\\\NEXT\\\\examen\\\\pages\\\\add-playlist.js\",\n                    lineNumber: 34,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"form\", {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                            type: \"text\",\n                            placeholder: \"Descriere\",\n                            minLength: 5,\n                            value: descriere,\n                            onChange: (event)=>{\n                                setDescriere(event.target.value);\n                            }\n                        }, void 0, false, {\n                            fileName: \"E:\\\\Post Internship\\\\NEXT\\\\examen\\\\pages\\\\add-playlist.js\",\n                            lineNumber: 37,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"E:\\\\Post Internship\\\\NEXT\\\\examen\\\\pages\\\\add-playlist.js\",\n                            lineNumber: 46,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"E:\\\\Post Internship\\\\NEXT\\\\examen\\\\pages\\\\add-playlist.js\",\n                            lineNumber: 48,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                            type: \"submit\",\n                            onClick: (event)=>{\n                                handleSubmit(event);\n                            }\n                        }, void 0, false, {\n                            fileName: \"E:\\\\Post Internship\\\\NEXT\\\\examen\\\\pages\\\\add-playlist.js\",\n                            lineNumber: 49,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"E:\\\\Post Internship\\\\NEXT\\\\examen\\\\pages\\\\add-playlist.js\",\n                    lineNumber: 36,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"E:\\\\Post Internship\\\\NEXT\\\\examen\\\\pages\\\\add-playlist.js\",\n            lineNumber: 33,\n            columnNumber: 7\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hZGQtcGxheWxpc3QuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBMkM7QUFDVztBQUV2QyxRQUFRLENBQUNHLFdBQVcsR0FBRyxDQUFDO0lBQ3JDLEtBQUssTUFBRUMsU0FBUyxNQUFFQyxZQUFZLE1BQUlKLCtDQUFRLENBQUMsQ0FBRTtJQUM3QyxLQUFLLE1BQUVLLEdBQUcsTUFBRUMsTUFBTSxNQUFJTiwrQ0FBUSxDQUFDLENBQUU7SUFFakMsS0FBSyxDQUFDTyxZQUFZLFVBQVVDLEtBQUssR0FBSyxDQUFDO1FBQ3JDQSxLQUFLLENBQUNDLGNBQWM7UUFFcEIsR0FBRyxDQUFDQyxJQUFJLEdBQUdDLElBQUksQ0FBQ0MsR0FBRztRQUNuQkYsSUFBSSxHQUFHRyxNQUFNLENBQUNDLE1BQU0sQ0FBQ0osSUFBSSxFQUFFSyxLQUFLLENBQUMsQ0FBRSxHQUFFQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRUMsSUFBSSxDQUFDLENBQUU7UUFDekRDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDVCxJQUFJO0lBQ2hCLEVBQWlCO0lBQ2pCLEVBQWM7SUFDZCxFQUFXO0lBQ1gsRUFBUztJQUNULEVBQVU7SUFDVixFQUFLO0lBRUwsRUFBZ0Q7SUFDaEQsRUFBZTtJQUNmLEVBQTBDO0lBQzFDLEVBQTBDO0lBQzFDLEVBQU87SUFDUCxFQUFvQjtJQUNwQixFQUFnQztJQUNoQyxFQUFNO0lBQ1IsQ0FBQztJQUVELE1BQU07OEZBRURVLENBQUc7WUFBQ0MsU0FBUyxFQUFFcEIsa0ZBQWdCOzs0RkFDN0JzQixDQUFFOzhCQUFDLENBQWdCOzs7Ozs7NEZBRW5CQyxDQUFJOztvR0FDRkMsQ0FBSzs0QkFDSkMsSUFBSSxFQUFDLENBQU07NEJBQ1hDLFdBQVcsRUFBQyxDQUFXOzRCQUN2QkMsU0FBUyxFQUFFLENBQUM7NEJBQ1pDLEtBQUssRUFBRTFCLFNBQVM7NEJBQ2hCMkIsUUFBUSxHQUFHdEIsS0FBSyxHQUFLLENBQUM7Z0NBQ3BCSixZQUFZLENBQUNJLEtBQUssQ0FBQ3VCLE1BQU0sQ0FBQ0YsS0FBSzs0QkFDakMsQ0FBQzs7Ozs7O29HQUVGRyxDQUFFOzs7OztvR0FFRkEsQ0FBRTs7Ozs7b0dBQ0ZQLENBQUs7NEJBQ0pDLElBQUksRUFBQyxDQUFROzRCQUNiTyxPQUFPLEdBQUd6QixLQUFLLEdBQUssQ0FBQztnQ0FDbkJELFlBQVksQ0FBQ0MsS0FBSzs0QkFDcEIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU1iLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9leGFtZW4vLi9wYWdlcy9hZGQtcGxheWxpc3QuanM/MzFlNCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9BZGRQbGF5bGlzdC5tb2R1bGUuc2Nzcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBZGRQbGF5bGlzdCgpIHtcclxuICBjb25zdCBbZGVzY3JpZXJlLCBzZXREZXNjcmllcmVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtvcmEsIHNldE9yYV0gPSB1c2VTdGF0ZSgnJyk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBsZXQgZGF0ZSA9IERhdGUubm93KCk7XHJcbiAgICBkYXRlID0gTnVtYmVyKFN0cmluZyhkYXRlKS5zcGxpdCgnJykuc2xpY2UoNSwgMTIpLmpvaW4oJycpKTtcclxuICAgIGNvbnNvbGUubG9nKGRhdGUpO1xyXG4gICAgLy8gY29uc3QgZm9ybSA9IHtcclxuICAgIC8vICAgaWQ6IGRhdGUsXHJcbiAgICAvLyAgIHRpdGx1LFxyXG4gICAgLy8gICB1cmwsXHJcbiAgICAvLyAgIHN0aWwsXHJcbiAgICAvLyB9O1xyXG5cclxuICAgIC8vIGF3YWl0IGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2RiJywge1xyXG4gICAgLy8gICBoZWFkZXJzOiB7XHJcbiAgICAvLyAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgIC8vICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxyXG4gICAgLy8gICB9LFxyXG4gICAgLy8gICBtZXRob2Q6ICdQT1NUJyxcclxuICAgIC8vICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZm9ybSksXHJcbiAgICAvLyB9KTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxyXG4gICAgICAgIDxoMT5DcmVlYXphIHBsYXlsaXN0PC9oMT5cclxuXHJcbiAgICAgICAgPGZvcm0+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyaWVyZVwiXHJcbiAgICAgICAgICAgIG1pbkxlbmd0aD17NX1cclxuICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaWVyZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldERlc2NyaWVyZShldmVudC50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxiciAvPlxyXG5cclxuICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICBoYW5kbGVTdWJtaXQoZXZlbnQpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJzdHlsZXMiLCJBZGRQbGF5bGlzdCIsImRlc2NyaWVyZSIsInNldERlc2NyaWVyZSIsIm9yYSIsInNldE9yYSIsImhhbmRsZVN1Ym1pdCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJkYXRlIiwiRGF0ZSIsIm5vdyIsIk51bWJlciIsIlN0cmluZyIsInNwbGl0Iiwic2xpY2UiLCJqb2luIiwiY29uc29sZSIsImxvZyIsImRpdiIsImNsYXNzTmFtZSIsImNvbnRhaW5lciIsImgxIiwiZm9ybSIsImlucHV0IiwidHlwZSIsInBsYWNlaG9sZGVyIiwibWluTGVuZ3RoIiwidmFsdWUiLCJvbkNoYW5nZSIsInRhcmdldCIsImJyIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/add-playlist.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/add-playlist.js"));
module.exports = __webpack_exports__;

})();