"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getSong";
exports.ids = ["pages/api/getSong"];
exports.modules = {

/***/ "sql-next":
/*!***************************!*\
  !*** external "sql-next" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("sql-next");

/***/ }),

/***/ "(api)/./pages/api/getSong.js":
/*!******************************!*\
  !*** ./pages/api/getSong.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var sql_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sql-next */ \"sql-next\");\n/* harmony import */ var sql_next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sql_next__WEBPACK_IMPORTED_MODULE_0__);\n\nconst config = {\n    host: '127.0.0.1',\n    user: 'root',\n    password: '',\n    port: 3306\n};\n// eslint-disable-next-line import/no-anonymous-default-export\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{\n    const client = new sql_next__WEBPACK_IMPORTED_MODULE_0__.Client();\n    await client.connect(config);\n    console.log('Connected!');\n    const { method  } = req;\n    const db = client.db('examen');\n    const table = db.table('songs');\n    console.log(method);\n    if (method === 'POST') try {\n        const data = await table.findOne({\n            id: req.body.id\n        });\n        res.status(200).json({\n            result: data\n        });\n    } catch  {\n        res.status(400).json({\n            result: 'Could not insert'\n        });\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0U29uZy5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBaUM7QUFFakMsS0FBSyxDQUFDQyxNQUFNLEdBQUcsQ0FBQztJQUNkQyxJQUFJLEVBQUUsQ0FBVztJQUNqQkMsSUFBSSxFQUFFLENBQU07SUFDWkMsUUFBUSxFQUFFLENBQUU7SUFDWkMsSUFBSSxFQUFFLElBQUk7QUFDWixDQUFDO0FBRUQsRUFBOEQ7QUFDOUQsaUVBQU0sT0FBZ0JDLEdBQUcsRUFBRUMsR0FBRyxHQUFLLENBQUM7SUFDbEMsS0FBSyxDQUFDQyxNQUFNLEdBQUcsR0FBRyxDQUFDUiw0Q0FBTTtJQUN6QixLQUFLLENBQUNRLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDUixNQUFNO0lBQzNCUyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFZO0lBRXhCLEtBQUssQ0FBQyxDQUFDLENBQUNDLE1BQU0sRUFBQyxDQUFDLEdBQUdOLEdBQUc7SUFDdEIsS0FBSyxDQUFDTyxFQUFFLEdBQUdMLE1BQU0sQ0FBQ0ssRUFBRSxDQUFDLENBQVE7SUFDN0IsS0FBSyxDQUFDQyxLQUFLLEdBQUdELEVBQUUsQ0FBQ0MsS0FBSyxDQUFDLENBQU87SUFFOUJKLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxNQUFNO0lBRWxCLEVBQUUsRUFBRUEsTUFBTSxLQUFLLENBQU0sT0FDbkIsR0FBRyxDQUFDLENBQUM7UUFDSCxLQUFLLENBQUNHLElBQUksR0FBRyxLQUFLLENBQUNELEtBQUssQ0FBQ0UsT0FBTyxDQUFDLENBQUM7WUFDaENDLEVBQUUsRUFBRVgsR0FBRyxDQUFDWSxJQUFJLENBQUNELEVBQUU7UUFDakIsQ0FBQztRQUNEVixHQUFHLENBQUNZLE1BQU0sQ0FBQyxHQUFHLEVBQUVDLElBQUksQ0FBQyxDQUFDO1lBQUNDLE1BQU0sRUFBRU4sSUFBSTtRQUFDLENBQUM7SUFDdkMsQ0FBQyxDQUFDLEtBQUssRUFBQyxDQUFDO1FBQ1BSLEdBQUcsQ0FBQ1ksTUFBTSxDQUFDLEdBQUcsRUFBRUMsSUFBSSxDQUFDLENBQUM7WUFBQ0MsTUFBTSxFQUFFLENBQWtCO1FBQUMsQ0FBQztJQUNyRCxDQUFDO0FBQ0wsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2V4YW1lbi8uL3BhZ2VzL2FwaS9nZXRTb25nLmpzPzFiMWIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2xpZW50IH0gZnJvbSAnc3FsLW5leHQnO1xyXG5cclxuY29uc3QgY29uZmlnID0ge1xyXG4gIGhvc3Q6ICcxMjcuMC4wLjEnLFxyXG4gIHVzZXI6ICdyb290JyxcclxuICBwYXNzd29yZDogJycsXHJcbiAgcG9ydDogMzMwNixcclxufTtcclxuXHJcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBpbXBvcnQvbm8tYW5vbnltb3VzLWRlZmF1bHQtZXhwb3J0XHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIChyZXEsIHJlcykgPT4ge1xyXG4gIGNvbnN0IGNsaWVudCA9IG5ldyBDbGllbnQoKTtcclxuICBhd2FpdCBjbGllbnQuY29ubmVjdChjb25maWcpO1xyXG4gIGNvbnNvbGUubG9nKCdDb25uZWN0ZWQhJyk7XHJcblxyXG4gIGNvbnN0IHsgbWV0aG9kIH0gPSByZXE7XHJcbiAgY29uc3QgZGIgPSBjbGllbnQuZGIoJ2V4YW1lbicpO1xyXG4gIGNvbnN0IHRhYmxlID0gZGIudGFibGUoJ3NvbmdzJyk7XHJcblxyXG4gIGNvbnNvbGUubG9nKG1ldGhvZCk7XHJcblxyXG4gIGlmIChtZXRob2QgPT09ICdQT1NUJylcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB0YWJsZS5maW5kT25lKHtcclxuICAgICAgICBpZDogcmVxLmJvZHkuaWQsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXMuc3RhdHVzKDIwMCkuanNvbih7IHJlc3VsdDogZGF0YSB9KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICByZXMuc3RhdHVzKDQwMCkuanNvbih7IHJlc3VsdDogJ0NvdWxkIG5vdCBpbnNlcnQnIH0pO1xyXG4gICAgfVxyXG59O1xyXG4iXSwibmFtZXMiOlsiQ2xpZW50IiwiY29uZmlnIiwiaG9zdCIsInVzZXIiLCJwYXNzd29yZCIsInBvcnQiLCJyZXEiLCJyZXMiLCJjbGllbnQiLCJjb25uZWN0IiwiY29uc29sZSIsImxvZyIsIm1ldGhvZCIsImRiIiwidGFibGUiLCJkYXRhIiwiZmluZE9uZSIsImlkIiwiYm9keSIsInN0YXR1cyIsImpzb24iLCJyZXN1bHQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/getSong.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getSong.js"));
module.exports = __webpack_exports__;

})();