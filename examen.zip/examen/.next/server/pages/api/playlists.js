"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/playlists";
exports.ids = ["pages/api/playlists"];
exports.modules = {

/***/ "sql-next":
/*!***************************!*\
  !*** external "sql-next" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("sql-next");

/***/ }),

/***/ "(api)/./pages/api/playlists.js":
/*!********************************!*\
  !*** ./pages/api/playlists.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var sql_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sql-next */ \"sql-next\");\n/* harmony import */ var sql_next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sql_next__WEBPACK_IMPORTED_MODULE_0__);\n\nconst config = {\n    host: '127.0.0.1',\n    user: 'root',\n    password: '',\n    port: 3306\n};\n// eslint-disable-next-line import/no-anonymous-default-export\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{\n    const client = new sql_next__WEBPACK_IMPORTED_MODULE_0__.Client();\n    await client.connect(config);\n    console.log('Connected!');\n    const { method  } = req;\n    const db = client.db('examen');\n    const table = db.table('playlist');\n    console.log(method);\n    switch(method){\n        case 'GET':\n            const items = await table.find();\n            res.status(200).json({\n                result: items\n            });\n            break;\n        case 'POST':\n            try {\n                const data = await table.insertOne({\n                    id: req.body.id,\n                    descriere: req.body.descriere,\n                    data: req.body.data\n                });\n                res.status(200).json({\n                    result: data\n                });\n            } catch  {\n                res.status(400).json({\n                    result: 'Could not insert'\n                });\n            }\n            break;\n        case 'PUT':\n            break;\n        case 'DELETE':\n            break;\n        default:\n            res.status(400).json({\n                result: 'Internal server error'\n            });\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcGxheWxpc3RzLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFpQztBQUVqQyxLQUFLLENBQUNDLE1BQU0sR0FBRyxDQUFDO0lBQ2RDLElBQUksRUFBRSxDQUFXO0lBQ2pCQyxJQUFJLEVBQUUsQ0FBTTtJQUNaQyxRQUFRLEVBQUUsQ0FBRTtJQUNaQyxJQUFJLEVBQUUsSUFBSTtBQUNaLENBQUM7QUFFRCxFQUE4RDtBQUM5RCxpRUFBTSxPQUFnQkMsR0FBRyxFQUFFQyxHQUFHLEdBQUssQ0FBQztJQUNsQyxLQUFLLENBQUNDLE1BQU0sR0FBRyxHQUFHLENBQUNSLDRDQUFNO0lBQ3pCLEtBQUssQ0FBQ1EsTUFBTSxDQUFDQyxPQUFPLENBQUNSLE1BQU07SUFDM0JTLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQVk7SUFFeEIsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxFQUFDLENBQUMsR0FBR04sR0FBRztJQUN0QixLQUFLLENBQUNPLEVBQUUsR0FBR0wsTUFBTSxDQUFDSyxFQUFFLENBQUMsQ0FBUTtJQUM3QixLQUFLLENBQUNDLEtBQUssR0FBR0QsRUFBRSxDQUFDQyxLQUFLLENBQUMsQ0FBVTtJQUVqQ0osT0FBTyxDQUFDQyxHQUFHLENBQUNDLE1BQU07SUFFbEIsTUFBTSxDQUFFQSxNQUFNO1FBQ1osSUFBSSxDQUFDLENBQUs7WUFDUixLQUFLLENBQUNHLEtBQUssR0FBRyxLQUFLLENBQUNELEtBQUssQ0FBQ0UsSUFBSTtZQUM5QlQsR0FBRyxDQUFDVSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUMsQ0FBQztnQkFBQ0MsTUFBTSxFQUFFSixLQUFLO1lBQUMsQ0FBQztZQUN0QyxLQUFLO1FBRVAsSUFBSSxDQUFDLENBQU07WUFDVCxHQUFHLENBQUMsQ0FBQztnQkFDSCxLQUFLLENBQUNLLElBQUksR0FBRyxLQUFLLENBQUNOLEtBQUssQ0FBQ08sU0FBUyxDQUFDLENBQUM7b0JBQ2xDQyxFQUFFLEVBQUVoQixHQUFHLENBQUNpQixJQUFJLENBQUNELEVBQUU7b0JBQ2ZFLFNBQVMsRUFBRWxCLEdBQUcsQ0FBQ2lCLElBQUksQ0FBQ0MsU0FBUztvQkFDN0JKLElBQUksRUFBRWQsR0FBRyxDQUFDaUIsSUFBSSxDQUFDSCxJQUFJO2dCQUNyQixDQUFDO2dCQUNEYixHQUFHLENBQUNVLE1BQU0sQ0FBQyxHQUFHLEVBQUVDLElBQUksQ0FBQyxDQUFDO29CQUFDQyxNQUFNLEVBQUVDLElBQUk7Z0JBQUMsQ0FBQztZQUN2QyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUM7Z0JBQ1BiLEdBQUcsQ0FBQ1UsTUFBTSxDQUFDLEdBQUcsRUFBRUMsSUFBSSxDQUFDLENBQUM7b0JBQUNDLE1BQU0sRUFBRSxDQUFrQjtnQkFBQyxDQUFDO1lBQ3JELENBQUM7WUFFRCxLQUFLO1FBRVAsSUFBSSxDQUFDLENBQUs7WUFDUixLQUFLO1FBRVAsSUFBSSxDQUFDLENBQVE7WUFDWCxLQUFLOztZQUdMWixHQUFHLENBQUNVLE1BQU0sQ0FBQyxHQUFHLEVBQUVDLElBQUksQ0FBQyxDQUFDO2dCQUFDQyxNQUFNLEVBQUUsQ0FBdUI7WUFBQyxDQUFDOztBQUU5RCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZXhhbWVuLy4vcGFnZXMvYXBpL3BsYXlsaXN0cy5qcz9jYWZkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENsaWVudCB9IGZyb20gJ3NxbC1uZXh0JztcclxuXHJcbmNvbnN0IGNvbmZpZyA9IHtcclxuICBob3N0OiAnMTI3LjAuMC4xJyxcclxuICB1c2VyOiAncm9vdCcsXHJcbiAgcGFzc3dvcmQ6ICcnLFxyXG4gIHBvcnQ6IDMzMDYsXHJcbn07XHJcblxyXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgaW1wb3J0L25vLWFub255bW91cy1kZWZhdWx0LWV4cG9ydFxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyAocmVxLCByZXMpID0+IHtcclxuICBjb25zdCBjbGllbnQgPSBuZXcgQ2xpZW50KCk7XHJcbiAgYXdhaXQgY2xpZW50LmNvbm5lY3QoY29uZmlnKTtcclxuICBjb25zb2xlLmxvZygnQ29ubmVjdGVkIScpO1xyXG5cclxuICBjb25zdCB7IG1ldGhvZCB9ID0gcmVxO1xyXG4gIGNvbnN0IGRiID0gY2xpZW50LmRiKCdleGFtZW4nKTtcclxuICBjb25zdCB0YWJsZSA9IGRiLnRhYmxlKCdwbGF5bGlzdCcpO1xyXG5cclxuICBjb25zb2xlLmxvZyhtZXRob2QpO1xyXG5cclxuICBzd2l0Y2ggKG1ldGhvZCkge1xyXG4gICAgY2FzZSAnR0VUJzpcclxuICAgICAgY29uc3QgaXRlbXMgPSBhd2FpdCB0YWJsZS5maW5kKCk7XHJcbiAgICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKHsgcmVzdWx0OiBpdGVtcyB9KTtcclxuICAgICAgYnJlYWs7XHJcblxyXG4gICAgY2FzZSAnUE9TVCc6XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHRhYmxlLmluc2VydE9uZSh7XHJcbiAgICAgICAgICBpZDogcmVxLmJvZHkuaWQsXHJcbiAgICAgICAgICBkZXNjcmllcmU6IHJlcS5ib2R5LmRlc2NyaWVyZSxcclxuICAgICAgICAgIGRhdGE6IHJlcS5ib2R5LmRhdGEsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oeyByZXN1bHQ6IGRhdGEgfSk7XHJcbiAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgcmVzdWx0OiAnQ291bGQgbm90IGluc2VydCcgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGJyZWFrO1xyXG5cclxuICAgIGNhc2UgJ1BVVCc6XHJcbiAgICAgIGJyZWFrO1xyXG5cclxuICAgIGNhc2UgJ0RFTEVURSc6XHJcbiAgICAgIGJyZWFrO1xyXG5cclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgcmVzdWx0OiAnSW50ZXJuYWwgc2VydmVyIGVycm9yJyB9KTtcclxuICB9XHJcbn07XHJcbiJdLCJuYW1lcyI6WyJDbGllbnQiLCJjb25maWciLCJob3N0IiwidXNlciIsInBhc3N3b3JkIiwicG9ydCIsInJlcSIsInJlcyIsImNsaWVudCIsImNvbm5lY3QiLCJjb25zb2xlIiwibG9nIiwibWV0aG9kIiwiZGIiLCJ0YWJsZSIsIml0ZW1zIiwiZmluZCIsInN0YXR1cyIsImpzb24iLCJyZXN1bHQiLCJkYXRhIiwiaW5zZXJ0T25lIiwiaWQiLCJib2R5IiwiZGVzY3JpZXJlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/playlists.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/playlists.js"));
module.exports = __webpack_exports__;

})();