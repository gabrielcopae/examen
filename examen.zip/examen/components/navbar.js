import styles from '../styles/Navbar.module.scss';
import Link from 'next/link';
const Navbar = () => (
  <div>
    <ul className={styles.list}>
      <Link href="/">
        <a>
          <li>Acasa</li>
        </a>
      </Link>
      <Link href="/add-song">
        <a>
          <li>Adauga melodie</li>
        </a>
      </Link>
      <Link href="/add-playlist">
        <a>
          <li>Creeaza playlist</li>
        </a>
      </Link>
    </ul>
  </div>
);

export default Navbar;
