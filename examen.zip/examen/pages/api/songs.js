import { Client } from 'sql-next';

const config = {
  host: '127.0.0.1',
  user: 'root',
  password: '',
  port: 3306,
};

// eslint-disable-next-line import/no-anonymous-default-export
export default async (req, res) => {
  const client = new Client();
  await client.connect(config);
  console.log('Connected!');

  const { method } = req;
  const db = client.db('examen');
  const table = db.table('songs');

  console.log(method);

  switch (method) {
    case 'GET':
      if (req.body.id) {
        const item = await table.findOne({ id: req.body.id });
        console.log(item);
        res.status(200).json({ result: item });
      } else {
        const items = await table.find();
        console.log(items);
        res.status(200).json({ result: items });
      }
      break;

    case 'POST':
      try {
        console.log(req.body.id, req.body.titlu, req.body.stil);
        const data = await table.insertOne({
          id: req.body.id,
          titlu: req.body.titlu,
          url: req.body.url,
          stil: req.body.stil,
        });
        res.status(200).json({ result: data });
      } catch {
        res.status(400).json({ result: 'Could not insert' });
      }

      break;

    case 'PUT':
      try {
        const data = await table.update(
          { id: req.body.id },
          {
            titlu: req.body.titlu,
            url: req.body.url,
            stil: req.body.stil,
          }
        );
        res.status(200).json({ result: data });
      } catch {
        res.status(400).json({ result: 'Could not modify' });
      }

      break;

    case 'DELETE':
      try {
        console.log(req.body);
        const data = await table.update(
          { id: req.body },
          {
            titlu: '',
            url: '',
            stil: '',
          }
        );
        console.log(data);
        res.status(200).json({ result: data });
      } catch {
        res.status(400).json({ result: 'Could not modify' });
      }
      break;

    default:
      res.status(400).json({ result: 'Internal server error' });
  }
};
