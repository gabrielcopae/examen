// import { Client } from 'sql-next';

// const config = {
//   host: '127.0.0.1',
//   user: 'root',
//   password: '',
//   port: 3306,
// };

// // eslint-disable-next-line import/no-anonymous-default-export
// export default async (req, res) => {
//   const client = new Client();
//   await client.connect(config);
//   console.log('Connected!');

//   const { method } = req;
//   const db = client.db('examen');
//   const table = db.table('songs');

//   //   const { id } = req.query;
//   console.log(id);

//   //   if (method === 'POST')
//   //     try {
//   //       const data = await table.findOne({
//   //         id: req.body.id,
//   //       });
//   //       res.status(200).json({ result: data });
//   //     } catch {
//   //       res.status(400).json({ result: 'Could not insert' });
//   //     }
// };
