import { Client } from 'sql-next';

const config = {
  host: '127.0.0.1',
  user: 'root',
  password: '',
  port: 3306,
};

// eslint-disable-next-line import/no-anonymous-default-export
export default async (req, res) => {
  const client = new Client();
  await client.connect(config);
  console.log('Connected!');

  const { method } = req;
  const db = client.db('examen');
  const table = db.table('playlist');

  console.log(method);

  switch (method) {
    case 'GET':
      const items = await table.find();
      res.status(200).json({ result: items });
      break;

    case 'POST':
      try {
        const data = await table.insertOne({
          id: req.body.id,
          descriere: req.body.descriere,
          data: req.body.data,
        });
        res.status(200).json({ result: data });
      } catch {
        res.status(400).json({ result: 'Could not insert' });
      }

      break;

    case 'PUT':
      break;

    case 'DELETE':
      break;

    default:
      res.status(400).json({ result: 'Internal server error' });
  }
};
