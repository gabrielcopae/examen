import Head from 'next/head';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import Navbar from '../components/navbar';
import styles from '../styles/Home.module.scss';

export default function Home() {
  const [songs, setSongs] = useState([]);
  const [playlists, setPlaylists] = useState([]);

  useEffect(() => {
    const getSongs = async () => {
      const r = await fetch('http://localhost:3000/api/songs');
      const data = await r.json();
      const song = data.result;
      setSongs(song);
    };

    const getPlaylists = async () => {
      const r = await fetch('http://localhost:3000/api/playlists');
      const data = await r.json();
      const playlist = data.result;
      setPlaylists(data.result);
    };

    getSongs();
    getPlaylists();
  }, []);

  useEffect(() => {
    console.log(playlists);
  }, [playlists]);

  return (
    <div className={styles.container}>
      <div className={styles.songs}>
        <h2>Melodii</h2>
        {songs !== 'undefined' && songs ? (
          songs.map((song) => {
            if (song.titlu !== '')
              return (
                <Song
                  key={song.id}
                  titlu={song.titlu}
                  url={song.url}
                  id={song.id}
                  stil={song.stil}
                />
              );
          })
        ) : (
          <>Loading...</>
        )}
      </div>
      <div className={styles.songs}>
        <h2>Playlist-uri</h2>
        {playlists ? (
          playlists.map((playlist) => {
            if (playlist.descriere !== '')
              return (
                <Playlist
                  key={playlist.id}
                  descriere={playlist.descriere}
                  data={playlist.data}
                  id={playlist.id}
                />
              );
          })
        ) : (
          <>Loading...</>
        )}
      </div>
    </div>
  );
}

const Song = ({ titlu, url, stil, id, deletedID, setDeletedID }) => {
  const handleDelete = async (id) => {
    await fetch('http://localhost:3000/api/songs', {
      method: 'DELETE',
      body: JSON.stringify(id),
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    });
  };

  return (
    <div className={styles.song}>
      <Link href={`/song/${id}`}>
        <a>
          <div>
            <h3>{titlu}</h3>
            <hr />
            <div className={styles.url}>{url}</div>
            <h4>{stil}</h4>
          </div>
        </a>
      </Link>
      <div className={styles.right}>
        <Link href={`/change-song?id=${id}`}>
          <a>
            <h4>Modifica</h4>
          </a>
        </Link>
        <h4
          onClick={() => {
            handleDelete(id);
          }}
        >
          Sterge
        </h4>
      </div>
    </div>
  );
};

const Playlist = ({ descriere, id, data }) => {
  return (
    <>
      <div className={styles.playlist}>
        <Link href={`/song/${id}`}>
          <a>
            <div>
              <h3>{descriere}</h3>
              <hr />
              <div className={styles.url}>{data}</div>
            </div>
          </a>
        </Link>
        <div className={styles.right}>
          <h4>Modifica</h4>
          <h4
            onClick={() => {
              handleDelete(id);
            }}
          >
            Sterge
          </h4>
        </div>
      </div>
    </>
  );
};
