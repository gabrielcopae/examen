import { useEffect, useState } from 'react';
import styles from '../styles/AddPlaylist.module.scss';

export default function AddPlaylist() {
  const [descriere, setDescriere] = useState('');
  const [ora, setOra] = useState('');

  const [eroareDescriere, setEroareDescriere] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (descriere.length < 5) {
      setEroareDescriere(true);
    } else {
      let id = Date.now();
      id = Number(String(id).split('').slice(5, 12).join(''));

      const monthNames = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
      ];
      const dateObj = new Date();
      const month = monthNames[dateObj.getMonth()];
      const day = String(dateObj.getDate()).padStart(2, '0');
      const year = dateObj.getFullYear();
      const output = month + ', ' + day + ', ' + year;

      const form = {
        id,
        descriere,
        data: output,
      };

      await fetch('http://localhost:3000/api/playlists', {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        method: 'POST',
        body: JSON.stringify(form),
      });
    }
  };

  return (
    <>
      <div className={styles.container}>
        <h1>Creeaza playlist</h1>

        <form>
          <input
            type="text"
            placeholder="Descriere"
            minLength={5}
            value={descriere}
            onChange={(event) => {
              setDescriere(event.target.value);
            }}
          />
          <br />

          {eroareDescriere && (
            <h4 className={styles.eroare}>
              Descrierea trebuie sa contina cel putin 5 caractere
            </h4>
          )}

          <br />
          <input
            type="submit"
            onClick={(event) => {
              handleSubmit(event);
            }}
          />
        </form>
      </div>
    </>
  );
}
