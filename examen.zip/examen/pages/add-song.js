import { useEffect, useState } from 'react';
import styles from '../styles/AddSong.module.scss';

export default function AddSong() {
  const [titlu, setTitlu] = useState('');
  const [url, setUrl] = useState('');
  const [stil, setStil] = useState('');

  const [succes, setSucces] = useState(false);
  const [eroare, setEroare] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (
      (titlu.length > 5 && url.match(/http:/)) ||
      url.match(/https:/) ||
      (url.match(/www./) && stil)
    ) {
      let date = Date.now();
      date = Number(String(date).split('').slice(5, 12).join(''));
      const form = {
        id: date,
        titlu,
        url,
        stil,
      };

      await fetch('http://localhost:3000/api/songs', {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        method: 'POST',
        body: JSON.stringify(form),
      });

      setStil('');
      setTitlu('');
      setUrl('');
      setSucces(true);
      setEroare(false);
    } else {
      setEroare(true);
    }
  };

  return (
    <>
      <div className={styles.container}>
        <h1>Adauga melodie</h1>

        {succes && (
          <h4 className={styles.succes}>Melodia a fost adaugata cu succes.</h4>
        )}

        <form>
          <input
            type="text"
            placeholder="Titlu"
            value={titlu}
            onChange={(event) => {
              setTitlu(event.target.value);
            }}
          />
          {eroare && (
            <h4 className={styles.eroare}>
              Tiltul trebuie sa aiba minim 5 caractere.
            </h4>
          )}

          <br />
          <input
            type="text"
            placeholder="URL"
            value={url}
            onChange={(event) => {
              setUrl(event.target.value);
            }}
          />
          {eroare && (
            <h4 className={styles.eroare}>URL-ul trebuie sa fie valid</h4>
          )}
          <br />

          <input
            type="text"
            placeholder="Stil"
            value={stil}
            onChange={(event) => {
              setStil(event.target.value);
            }}
          />
          {eroare && (
            <h4 className={styles.eroare}>Stilul este obligatoriu.</h4>
          )}

          <br />
          <input
            type="submit"
            onClick={(event) => {
              handleSubmit(event);
            }}
          />
        </form>
      </div>
    </>
  );
}
