import { useEffect, useState } from 'react';
import styles from '../styles/AddSong.module.scss';
import getSong from './api/getSong';
import { useRouter } from 'next/router';
export default function AddSong() {
  const [titlu, setTitlu] = useState('');
  const [url, setUrl] = useState('');
  const [stil, setStil] = useState('');
  const [succes, setSucces] = useState(false);
  const { query } = useRouter();

  const handleSubmit = async (event) => {
    event.preventDefault();

    let date = Date.now();
    date = Number(String(date).split('').slice(5, 12).join(''));
    console.log(date);
    const form = {
      id: date,
      titlu,
      url,
      stil,
    };

    await fetch('http://localhost:3000/api/songs', {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      method: 'PUT',
      body: JSON.stringify(form),
    });

    setStil('');
    setTitlu('');
    setUrl('');
    setSucces(true);
  };

  return (
    <>
      <div className={styles.container}>
        <h1>Schimba campuri melodie</h1>

        {succes && (
          <h4 className={styles.succes}>Melodia a fost schimbata cu succes.</h4>
        )}

        <form>
          <input
            type="text"
            placeholder="Titlu"
            value={titlu}
            onChange={(event) => {
              setTitlu(event.target.value);
            }}
          />
          <br />
          <input
            type="text"
            placeholder="URL"
            value={url}
            onChange={(event) => {
              setUrl(event.target.value);
            }}
          />
          <br />
          <input
            type="text"
            placeholder="Stil"
            value={stil}
            onChange={(event) => {
              setStil(event.target.value);
            }}
          />
          <br />
          <input
            type="submit"
            onClick={(event) => {
              handleSubmit(event);
            }}
          />
        </form>
      </div>
    </>
  );
}
